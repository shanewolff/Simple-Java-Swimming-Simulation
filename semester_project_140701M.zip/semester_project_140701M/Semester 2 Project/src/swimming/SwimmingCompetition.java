package swimming;

import java.util.ArrayList;

// Class which represents the competition; includes components of the competition.
public class SwimmingCompetition {
	public static ArrayList<Person> persons;
	public static ArrayList<Swimmer> swimmers; 
	public static ArrayList<MaleSwimmer> maleSwimmers; 
	public static ArrayList<FemaleSwimmer> femaleSwimmers;
	public static ArrayList<Judge> judges;
	public static ArrayList<Spectator> spectators;
	public static ArrayList<Staff> staff;
	public static SwimmingPool pool;
	public static String competitionType;
	public static int stroke;
	public static ScoreBoard scoreBoard;
	public static Pavillion pavillion;
	
	//Constructor - Initiating Array List Objects...
	public SwimmingCompetition() {
		persons = new ArrayList<Person>();
		swimmers = new ArrayList<Swimmer>();
		maleSwimmers = new ArrayList<MaleSwimmer>();
		femaleSwimmers = new ArrayList<FemaleSwimmer>();
		judges = new ArrayList<Judge>();
		spectators = new ArrayList<Spectator>();
		staff = new ArrayList<Staff>();
		pool = new SwimmingPool();
		scoreBoard = new ScoreBoard();
		pavillion = new Pavillion();
	}
	
	
	public static void startCompetition() {
		// Call the judge's method to start the competition
		judges.get(0).blow(competitionType);
		
		// Staff helps the judge
		for (Staff staffPerson : staff) {
			staffPerson.helpJudge(judges.get(0));
		}
	}
}
