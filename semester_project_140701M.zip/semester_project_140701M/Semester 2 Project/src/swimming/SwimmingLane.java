package swimming;

public class SwimmingLane {
	private Swimmer swimmer;	// Keeps track of the swimmer occupied
	private TouchPad touchPad;	// Touch pad of the lane
	
	// Constructor
	public SwimmingLane() {
		touchPad = new TouchPad();
	}
	
	// Returns the touch pad
	public TouchPad getTouchPad() {
		return touchPad;
	}
	
	// Set the swimmer to the lane
	public void setSwimmer(Swimmer swimmer) {
		this.swimmer = swimmer;
	}
	
	// Returns the occupied swimmer
	public Swimmer getSwimmer() {
		return swimmer;
	}
}
