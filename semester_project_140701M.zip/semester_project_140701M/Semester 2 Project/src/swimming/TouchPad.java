package swimming;

public class TouchPad {
	
	// Sends the swimmer object and the finishing time to the Score Board
	public void touch(Swimmer swimmer) {
		SwimmingCompetition.scoreBoard.sendResult(swimmer, System.currentTimeMillis());
	}
}