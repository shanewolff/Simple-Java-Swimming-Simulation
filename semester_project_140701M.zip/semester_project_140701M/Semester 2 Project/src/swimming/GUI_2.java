package swimming;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.SystemColor;
import java.util.ArrayList;

import javax.swing.JTable;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;

// Second Window
public class GUI_2 extends JFrame {

	// Window components declaration
	private JPanel contentPane;
	private JLabel label_swimmer5;
	private JLabel label_swimmer4;
	private JLabel label_swimmer3;
	private JLabel label_swimmer2;
	private JLabel label_swimmer1;
	private JLabel label_pavillion;
	private JLabel label_lane1;
	private JLabel label_lane2;
	private JLabel label_lane3;
	private JLabel label_lane4;
	private JLabel label_lane5;
	private JLabel label_judge;
	public ArrayList<JLabel> swimmers = new ArrayList<JLabel>();
	private JLabel label_competitionType;
	private JComboBox<String> comboBox_type;
	private JButton button_setCompetition;
	private JLabel lblSelectTheType;
	private JLabel label_info2;
	private JButton button_whistle;
	private JLabel lblNewLabel;
	private JTable table;
	private JButton button_saveResult;
	private JLabel label_stroke;
	private JComboBox<String> comboBox_stroke;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame. 
	 */
	
	// COnstructor
	public GUI_2() {
		
		setResizable(false);
		setTitle("Swimming Competition");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 593, 670);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.control);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		label_swimmer5 = new JLabel("");
		label_swimmer5.setIcon(new ImageIcon(GUI_2.class.getResource("/swimming/swimmer_new.png")));
		label_swimmer5.setOpaque(true);
		label_swimmer5.setBackground(new Color(30, 144, 255));
		label_swimmer5.setBounds(129, 262, 40, 31);
		contentPane.add(label_swimmer5);
		label_swimmer5.setVisible(false);
		
		
		label_swimmer4 = new JLabel("");
		label_swimmer4.setIcon(new ImageIcon(GUI_2.class.getResource("/swimming/swimmer_new.png")));
		label_swimmer4.setOpaque(true);
		label_swimmer4.setBackground(new Color(30, 144, 255));
		label_swimmer4.setBounds(129, 220, 40, 31);
		contentPane.add(label_swimmer4);
		label_swimmer4.setVisible(false);
		
		
		label_swimmer3 = new JLabel("");
		label_swimmer3.setIcon(new ImageIcon(GUI_2.class.getResource("/swimming/swimmer_new.png")));
		label_swimmer3.setOpaque(true);
		label_swimmer3.setBackground(new Color(30, 144, 255));
		label_swimmer3.setBounds(129, 178, 40, 31);
		contentPane.add(label_swimmer3);
		label_swimmer3.setVisible(false);
		
		
		label_swimmer2 = new JLabel("");
		label_swimmer2.setIcon(new ImageIcon(GUI_2.class.getResource("/swimming/swimmer_new.png")));
		label_swimmer2.setOpaque(true);
		label_swimmer2.setBackground(new Color(30, 144, 255));
		label_swimmer2.setBounds(129, 136, 40, 31);
		contentPane.add(label_swimmer2);
		label_swimmer2.setVisible(false);
		
		
		label_swimmer1 = new JLabel("");
		label_swimmer1.setBackground(new Color(30, 144, 255));
		label_swimmer1.setOpaque(true);
		label_swimmer1.setIcon(new ImageIcon(GUI_2.class.getResource("/swimming/swimmer_new.png")));
		label_swimmer1.setBounds(129, 94, 40, 31);
		contentPane.add(label_swimmer1);
		label_swimmer1.setVisible(false);
		
		swimmers.add(label_swimmer1);
		swimmers.add(label_swimmer2);
		swimmers.add(label_swimmer3);
		swimmers.add(label_swimmer4);
		swimmers.add(label_swimmer5);
		
		label_pavillion = new JLabel("");
		label_pavillion.setIcon(new ImageIcon(GUI_2.class.getResource("/swimming/audience_new.png")));
		label_pavillion.setOpaque(true);
		label_pavillion.setForeground(Color.BLACK);
		label_pavillion.setBackground(SystemColor.activeCaptionBorder);
		label_pavillion.setBounds(151, 11, 360, 72);
		contentPane.add(label_pavillion);
		
		label_lane1 = new JLabel("");
		label_lane1.setBackground(new Color(30, 144, 255));
		label_lane1.setOpaque(true);
		label_lane1.setBounds(129, 94, 404, 31);
		contentPane.add(label_lane1);
		
		label_lane2 = new JLabel("");
		label_lane2.setBackground(new Color(30, 144, 255));
		label_lane2.setOpaque(true);
		label_lane2.setBounds(129, 136, 404, 31);
		contentPane.add(label_lane2);
		
		label_lane3 = new JLabel("");
		label_lane3.setBackground(new Color(30, 144, 255));
		label_lane3.setOpaque(true);
		label_lane3.setBounds(129, 178, 404, 31);
		contentPane.add(label_lane3);
		
		label_lane4 = new JLabel("");
		label_lane4.setOpaque(true);
		label_lane4.setBackground(new Color(30, 144, 255));
		label_lane4.setBounds(129, 220, 404, 31);
		contentPane.add(label_lane4);
		
		label_lane5 = new JLabel("");
		label_lane5.setOpaque(true);
		label_lane5.setBackground(new Color(30, 144, 255));
		label_lane5.setBounds(129, 262, 404, 31);
		contentPane.add(label_lane5);
		
		label_judge = new JLabel("");
		label_judge.setIcon(new ImageIcon(GUI_2.class.getResource("/swimming/judge.jpg")));
		label_judge.setOpaque(true);
		label_judge.setBounds(10, 105, 109, 146);
		contentPane.add(label_judge);
		
		label_competitionType = new JLabel("Competition Type");
		label_competitionType.setFont(new Font("Tahoma", Font.PLAIN, 11));
		label_competitionType.setBounds(10, 353, 90, 14);
		contentPane.add(label_competitionType);
		
		comboBox_type = new JComboBox<String>();
		comboBox_type.setModel(new DefaultComboBoxModel<String>(new String[] {"Male", "Female"}));
		comboBox_type.setFont(new Font("Tahoma", Font.PLAIN, 11));
		comboBox_type.setBounds(103, 350, 66, 20);
		contentPane.add(comboBox_type);
		
		button_setCompetition = new JButton("Set the Competition");
		button_setCompetition.setFont(new Font("Tahoma", Font.BOLD, 11));
		button_setCompetition.setBounds(383, 349, 150, 23);
		contentPane.add(button_setCompetition);
		
		lblSelectTheType = new JLabel("Select the type of competition and the stroke and click on the button \"Set the Competition\".");
		lblSelectTheType.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		lblSelectTheType.setBounds(10, 325, 560, 14);
		contentPane.add(lblSelectTheType);
		
		label_info2 = new JLabel("Now the swimmers are ready to swim. Click on \"Whistle\" to start the game.");
		label_info2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		label_info2.setBounds(10, 390, 435, 14);
		contentPane.add(label_info2);
		label_info2.setEnabled(false);
		
		button_whistle = new JButton("Whistle!");
		button_whistle.setFont(new Font("Tahoma", Font.BOLD, 11));
		button_whistle.setBounds(444, 383, 89, 23);
		contentPane.add(button_whistle);
		button_whistle.setEnabled(false);
		
		lblNewLabel = new JLabel("Score Board");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel.setBounds(10, 415, 90, 14);
		contentPane.add(lblNewLabel);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"Swimmer", "Elapsed Time in Seconds", "Rank"},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
			},
			new String[] {
				"New column", "New column", "New column"
			}
		));
		table.getColumnModel().getColumn(0).setResizable(false);
		table.getColumnModel().getColumn(0).setPreferredWidth(114);
		table.getColumnModel().getColumn(1).setResizable(false);
		table.getColumnModel().getColumn(1).setPreferredWidth(121);
		table.getColumnModel().getColumn(2).setResizable(false);
		table.getColumnModel().getColumn(2).setPreferredWidth(23);
		table.setBounds(10, 440, 383, 96);
		contentPane.add(table);
		table.setEnabled(false);
		
		button_saveResult = new JButton("Save this Result");
		button_saveResult.setFont(new Font("Tahoma", Font.BOLD, 11));
		button_saveResult.setBounds(403, 513, 130, 23);
		contentPane.add(button_saveResult);
		button_saveResult.setEnabled(false);
		
		label_stroke = new JLabel("Stroke");
		label_stroke.setFont(new Font("Tahoma", Font.PLAIN, 11));
		label_stroke.setBounds(185, 353, 46, 14);
		contentPane.add(label_stroke);
		
		comboBox_stroke = new JComboBox<String>();
		comboBox_stroke.setModel(new DefaultComboBoxModel<String>(new String[] {"Butterfly", "Backstroke", "Freestyle", "Breaststroke"}));
		comboBox_stroke.setFont(new Font("Tahoma", Font.PLAIN, 11));
		comboBox_stroke.setBounds(229, 350, 90, 20);
		contentPane.add(comboBox_stroke);
		
		// Set the competition according to the selected gender and stroke
		button_setCompetition.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				button_setCompetition.setEnabled(false);
				label_info2.setEnabled(true);
				button_whistle.setEnabled(true);
				table.setEnabled(true);
				
				// Register relevant spectators to the score board
				for (Observer i : SwimmingCompetition.spectators) {
					SwimmingCompetition.scoreBoard.register(i);
				}
				
				// Set lanes and swimmers
				String [] names = Control.getNames((String) comboBox_type.getSelectedItem());
				setCompetition();
				Control.setLanes(SwimmingCompetition.competitionType);
				
				// Show the names of the swimmers in the score board
				for (int n = 0; n < names.length; ++n) {
					table.setValueAt(names[n], n + 1, 0);
				}
				
				setStroke();
			}
		});
		
		
		// Start the competition
		button_whistle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				button_whistle.setEnabled(false);
				String type = SwimmingCompetition.competitionType;
				SwimmingCompetition.startCompetition();
				
				// New thread to update swimmer position in the interface
				new Thread() { 
					public void run() {
						if (type == "Male") {
							int num = SwimmingCompetition.maleSwimmers.size();
							for (int n = 0; n < num; n++) {
								Swimmer swimmer = SwimmingCompetition.pool.getLaneList().get(n).getSwimmer();
								while (swimmer.getSwimmingStatus()) {
									for (int i = 0; i < num; i++) {
										int x = (int) (SwimmingCompetition.pool.getLaneList().get(i).getSwimmer().getCoordinate()/2.747252747252747);
										swimmers.get(i).setBounds(129 + x, swimmers.get(i).getBounds().y, 40, 31);
									}
									
									try {
										double randomNum1 = Math.random() * 10;
						    			double randomNum2 = Math.random() * 100;
						    			double sleepNum = randomNum1 + randomNum2;
										Thread.sleep((long) sleepNum);
									} 
									
									catch (InterruptedException e) {
										e.printStackTrace();
									}
									
								}
									
							}
						}
						
						else {
							int num = SwimmingCompetition.femaleSwimmers.size();
							for (int n = 0; n < num; n++) {
								Swimmer swimmer = SwimmingCompetition.pool.getLaneList().get(n).getSwimmer();
								while (swimmer.getSwimmingStatus()) {
									for (int i = 0; i < num; i++) {
										int x = (int) (SwimmingCompetition.pool.getLaneList().get(i).getSwimmer().getCoordinate()/2.747252747252747);
										swimmers.get(i).setBounds(129 + x, swimmers.get(i).getBounds().y, 40, 31);
									}
									
									try {
										Thread.sleep(10);
									}
									
									catch (InterruptedException e) {
										e.printStackTrace();
									}
									
								}
									
							}
						}
						
						SwimmingCompetition.scoreBoard.setScoreBoard();
						
						ArrayList<ArrayList<Object>> results = SwimmingCompetition.scoreBoard.getFinalResults();
						int num = results.size();
						for (int k = 0; k < num; k++) {
							ArrayList<Object> swimmerResult = results.get(k);
							table.setValueAt(swimmerResult.get(0), k + 1, 0);
							table.setValueAt(swimmerResult.get(1), k + 1, 1);
							table.setValueAt(Integer.valueOf(k + 1), k + 1, 2);
						}
						
						button_saveResult.setEnabled(true);
					}
					
					
				}.start();

				
				
			}
		});
		
		// Saves the result of the game
		button_saveResult.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				SwimmingCompetition.scoreBoard.saveResult();
				button_saveResult.setEnabled(false);
			}
		});
	}
	
	// Method which sets the competition according to gender
	public void setCompetition() {
		if (SwimmingCompetition.competitionType == "Male") {
			int num = SwimmingCompetition.maleSwimmers.size();
					for (int n = 0; n < num; n++) {
						JLabel swimmer = swimmers.get(n);
						swimmer.setVisible(true);
					}
		}
		
		else {
			int num = SwimmingCompetition.femaleSwimmers.size();
			for (int n = 0; n < num; n++) {
				JLabel swimmer = swimmers.get(n);
				swimmer.setVisible(true);
			}
		}
		
	}
	
	// // Method which sets the competition according to gender
	public void setStroke() {
		if (comboBox_stroke.getSelectedItem() == "Butterfly") {
			SwimmingCompetition.stroke = 0;
		}
		
		if (comboBox_stroke.getSelectedItem() == "Backstroke") {
			SwimmingCompetition.stroke = 1;
		}
		
		if (comboBox_stroke.getSelectedItem() == "Freestyle") {
			SwimmingCompetition.stroke = 3;
		}
		
		if (comboBox_stroke.getSelectedItem() == "Breaststroke") {
			SwimmingCompetition.stroke = 2;
		}
	}
}
