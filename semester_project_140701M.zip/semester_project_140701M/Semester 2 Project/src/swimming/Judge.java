package swimming;

import java.util.ArrayList;

//Inherits fields and methods from Person class
public class Judge extends Person {
	
	private ArrayList<ArrayList<Object>> finalResults;	// Stores the final result of the competition
	
	//Constructor
	public Judge(String name) {
		super(name); //Calls super class constructor
		SwimmingCompetition.judges.add(this); //Adds newly created object to the array list
		finalResults = new ArrayList<ArrayList<Object>>();
	}
	
	//Method for blowing the whistle
	public void blow(String type) {
		// Sets the start time of the competition
		SwimmingCompetition.scoreBoard.setStartTime(System.currentTimeMillis());
		
		// Start all swimmers' swimming threads after verifying whether it is a male or female competition
		if (type == "Male") {
			SwimmingCompetition.maleSwimmers.get(0).setStroke(SwimmingCompetition.stroke);
			int num = SwimmingCompetition.maleSwimmers.size();
			for (int n = 0; n < num; ++n) {
				Swimmer swimmer = SwimmingCompetition.maleSwimmers.get(n);
				new Thread(swimmer).start();
			}
		}
	 
		else {
			SwimmingCompetition.femaleSwimmers.get(0).setStroke(SwimmingCompetition.stroke);
			int num = SwimmingCompetition.femaleSwimmers.size();
			for (int n = 0; n < num; ++n) {
				Swimmer swimmer = SwimmingCompetition.femaleSwimmers.get(n);
				new Thread(swimmer).start();
			}
		}
	}
	
	public void receiveResult() {
		this.finalResults = SwimmingCompetition.scoreBoard.getFinalResults();
	}
 }
