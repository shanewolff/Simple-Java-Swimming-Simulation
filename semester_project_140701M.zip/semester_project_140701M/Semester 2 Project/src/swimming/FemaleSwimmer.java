package swimming;

//Inherits fields and methods from Swimmer class and implements ISwimmer interface
public class FemaleSwimmer extends Swimmer implements ISwimmer {
	
	private final String gender = "Female"; //Gender is fixed
	private static int stroke; // Stroke number
	
	//Constructor
	public FemaleSwimmer(String name, int age) { //Name is parameterized
		super(name, age); //Calls super class constructor
		SwimmingCompetition.femaleSwimmers.add(this); //Adds newly created object to the array list
		suitColour = "Red"; //Inherited field is set
	}
	
	// Swimming Thread Procedure
    public void run() {
    	isSwimming = true;
    	while (coordinate <= 1000) {
    		stepSwim(setStyle(stroke));
    		try {
				Thread.sleep((long) (Math.random() * 100));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
    	}
    	// Touches the touch pad after finish swimming
    	touch();
    	isSwimming = false;
    }
	
	//Describes the Butterfly Stroke
	@Override
	public double butterflyStroke() {
		return Math.random() + 0.2;
	}
	
	//Describes the Back Stroke
	@Override
	public double backStroke() {
		return Math.random();
	}
	
	//Describes the Breast Stroke
	@Override
	public double breastStroke() {
		return Math.random() + 0.1;
	}
	
	//Describes the Free Style
	@Override
	public double freeStyle() {
		return Math.random() + 0.3;
	}
	
	// Choose the style and returns a number to step swim
	public double setStyle(int stroke) {
		if (stroke == 0) {
			return butterflyStroke();
		}
		
		else if (stroke == 1) {
			return backStroke();
		}
		
		else if (stroke == 2) {
			return breastStroke();
		}
		
		else {
			return freeStyle();
		}
	}
	
	//Returns the colour of the suit
	@Override
	public String getSuitColour() {
		return suitColour;
		
	}
	
	public void setStroke(int n) {
		stroke = n;
	}
}
