package swimming;

import java.util.ArrayList;

public class SwimmingPool {
	// Keeps a set of lanes
	private ArrayList <SwimmingLane> lanes;
	
	// Constructor
	public SwimmingPool () {
		// Adding new 5 lanes to the pool
		lanes = new ArrayList<SwimmingLane>();
		SwimmingLane lane1 = new SwimmingLane();
		lanes.add(lane1);
		SwimmingLane lane2 = new SwimmingLane();
		lanes.add(lane2);
		SwimmingLane lane3 = new SwimmingLane();
		lanes.add(lane3);
		SwimmingLane lane4 = new SwimmingLane();
		lanes.add(lane4);
		SwimmingLane lane5 = new SwimmingLane();
		lanes.add(lane5);
	}
	
	// Returns the lane list
	public ArrayList<SwimmingLane> getLaneList() {
		return this.lanes;
	}
};
