package swimming;

// Supportive class for verification procedures when interacting with Interface
public class Verify {
	
	// Checks the given name is unique in the competition
	public static boolean isNameUnique(String name) {
		if (getValidName(name) == null) {
			return false;
		}
		
		String validName = getValidName(name);
		
		if (SwimmingCompetition.persons.isEmpty()) {
			return true;
		}
		
		else {
			for (Person p : SwimmingCompetition.persons) {
				if (p.getName().equals(validName)) {
					return false;
				}
			}
			return true;
		}
	}
	
	// Returns a valid name by truncating unnecessary white spaces
	public static String getValidName(String name) {
		if (name.trim().isEmpty()) {
			return null;
		}
		return name.trim();
	}
	
	// Checks if the given age is valid
	public static Integer isValidAge(String age) {
		int validAge;
		
		try {
			validAge = Integer.parseInt(age.trim());
		}
		
		catch (NumberFormatException e){
			return null;
		}
		
		if (validAge <= 0) {
			return null;
		}
		
		else {
			return validAge;
		}
	}
	
	// Checks if the user can start the competition
	public static boolean isValidToStart() {
		if (SwimmingCompetition.maleSwimmers.size() < 2) {
			return false;
		}
		
		if (SwimmingCompetition.femaleSwimmers.size() < 2) {
			return false;
		}
		
		if (SwimmingCompetition.judges.isEmpty()) {
			return false;
		}
		
		if (SwimmingCompetition.staff.isEmpty()) {
			return false;
		}
		
		if (SwimmingCompetition.spectators.isEmpty()) {
			return false;
		}
		
		else {
			return true;
		}
	}
	
	
	
}
