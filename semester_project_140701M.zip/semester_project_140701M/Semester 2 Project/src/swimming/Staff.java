package swimming;

//Inherits fields and methods from Person class
public class Staff extends Person {
    
    public Staff(String name) { //Constructor
    	super(name);
    	SwimmingCompetition.staff.add(this); //Adds newly created object to the array list
    }
    
    // Helps the specified judge
    public void helpJudge(Judge judge) {
    	
    }
}
