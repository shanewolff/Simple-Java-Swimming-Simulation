package swimming;

//Inherits fields and methods from Person class
public abstract class Swimmer extends Person implements Runnable {
	
	private int age;
	protected String suitColour;
    private SwimmingLane lane;
    protected double coordinate = 0;
    protected Boolean isSwimming = null;
    
    //Constructor
    public Swimmer(String name, int age) {
    	super(name); //Calls the constructor of the super class
    	this.age = age;
    	SwimmingCompetition.swimmers.add(this); //Adds the newly created object to the competition
    }
    
    // Returns whether swimmer swims or not;
    public boolean getSwimmingStatus() {
    	return isSwimming;
    }
    
    // Notify the touch pad that swimmer has finished swimming
    protected void touch() {
		this.lane.getTouchPad().touch(this);
		
	}
    
    //Returns the lane number
    public void setLane(SwimmingLane lane) {
    	this.lane = lane; 
    }
    
    //Returns the lane of the swimmer
    public SwimmingLane getLane() {
    	return lane;
    }
    
    // Swimming method for one step forward
    public void stepSwim(double increment) {
    	coordinate = coordinate + increment;
    }
    
    // Returns the distance swum by the swimmer
    public double getCoordinate() {
    	return coordinate;
    }
}
