package swimming;

//Inherits fields and methods from Swimmer class and implements ISwimmer interface
public class MaleSwimmer extends Swimmer implements ISwimmer {
	
	private final String gender = "Male"; //Gender is fixed
	private static int stroke; // Stroke number
	
	//Constructor
	public MaleSwimmer(String name, int age) { //Name is parameterized
		super(name, age); //Calls super class constructor
		SwimmingCompetition.maleSwimmers.add(this); //Adds newly created object to the array list
		suitColour = "Blue"; //Inherited field is set
	}
	
	// Swimming thread procedure
    public void run() {
    	isSwimming = true;
    	while (coordinate <= 1000) {
    		stepSwim(setStyle(stroke));
    		
    		try {
				Thread.sleep((long) (Math.random() * 100));
			}
    		
    		catch (InterruptedException e) {
				e.printStackTrace();
			}
    	}
    	// Touches the touch pad after finishing swimming
    	touch();
    	isSwimming = false;
    }

	//Describes the Butterfly Stroke
	@Override
	public double butterflyStroke() {
		return Math.random() + 0.7;
	}

	//Describes the Back Stroke
	@Override
	public double backStroke() {
		return Math.random() + 0.5;
	}

	//Describes the Breast Stroke
	@Override
	public double breastStroke() {
		return Math.random() + 0.6;
	}

	//Describes the Free Style
	@Override
	public double freeStyle() {
		return Math.random() + 0.8;
	}
	
	// Choose the style and returns a number to step swim
	public double setStyle(int stroke) {
		if (stroke == 0) {
			return butterflyStroke();
		}
		
		else if (stroke == 1) {
			return backStroke();
		}
		
		else if (stroke == 2) {
			return breastStroke();
		}
		
		else {
			return freeStyle();
		}
	}
	

	// Returns the color of the suit
	@Override
	public String getSuitColour() {
		return suitColour;
	}
	
	public void setStroke(int n) {
		stroke = n;
	}
}
