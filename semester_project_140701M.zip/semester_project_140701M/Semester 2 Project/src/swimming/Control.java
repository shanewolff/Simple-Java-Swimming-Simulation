package swimming;

import javax.swing.JOptionPane;

// A supportive class which includes methods to transfer data between the Model and the Interface 
public class Control {
	
	// Creates and adds new Swimmers to the competition
	public static boolean addSwimmer(String gender, String name, String age) {
		String swimmerName;
		int swimmerAge;
		
		if (gender == "Male") {
			if (SwimmingCompetition.maleSwimmers.size() > 4) {
				JOptionPane.showMessageDialog(null, "You have already created maximum number of male swimmers.","Swimmer Declaration", 0);
				return false;
			}
		}
		
		else {
			if (SwimmingCompetition.femaleSwimmers.size() > 4) {
				JOptionPane.showMessageDialog(null, "You have already created maximum number of female swimmers.","Swimmer Declaration", 0);
				return false;
			}
		}
		
		if (Verify.isNameUnique(name)) {
			swimmerName = Verify.getValidName(name);
		}
		
		else {
			JOptionPane.showMessageDialog(null, "Invalid Name!","Swimmer Name Declaration", 0);
			return false;
		}
		
		if (Verify.isValidAge(age) != null) {
			swimmerAge = Verify.isValidAge(age);
		}
		
		else {
			JOptionPane.showMessageDialog(null, "Invalid Age!","Swimmer Age Declaration", 0);
			return false;
		}
		
		if (gender.equals("Male")) {
			new MaleSwimmer(swimmerName, swimmerAge);
			JOptionPane.showMessageDialog(null, "Specified male swimmer is successfully added.","Swimmer Declaration", 1);
			return true;
		}
		
		else {
			new FemaleSwimmer(swimmerName, swimmerAge);
			JOptionPane.showMessageDialog(null, "Specified female swimmer is successfully added.","Swimmer Declaration", 1);
			return true;
		}
	}
	
	// Creates and adds new judges to the competition
	public static boolean addJudge(String name) {
		String judgeName;
		
		if (Verify.isNameUnique(name)) {
			judgeName = Verify.getValidName(name);
		}
		
		else {
			JOptionPane.showMessageDialog(null, "Invalid Name!","Judge Name Declaration", 0);
			return false;
		}
		
		new Judge(judgeName);
		JOptionPane.showMessageDialog(null, "Specified judge is successfully added.","Judge Declaration", 1);
		return true;
	}
	
	// Creates and adds new staff to the competition
	public static boolean addStaff(String name) {
		String staffName;
		
		if (Verify.isNameUnique(name)) {
			staffName = Verify.getValidName(name);
		}
		
		else {
			JOptionPane.showMessageDialog(null, "Invalid Name!","Staff Name Declaration", 0);
			return false;
		}
		
		new Staff(staffName);
		JOptionPane.showMessageDialog(null, "Specified staff is successfully added.","Staff Declaration", 1);
		return true;
	}
	
	// Creates and adds new spectators to the competition
	public static boolean addSpectator(String name) {
		String spectatorName;
		
		if (Verify.isNameUnique(name)) {
			spectatorName = Verify.getValidName(name);
		}
		
		else {
			JOptionPane.showMessageDialog(null, "Invalid Name!","Spectator Name Declaration", 0);
			return false;
		}
		
		new Spectator(spectatorName);
		JOptionPane.showMessageDialog(null, "Specified spectator is successfully added.","Spectator Declaration", 1);
		return true;
	}
	
	// Assigns swimmers to lanes
	public  static void setLanes(String gender) {
		if (gender == "Male") {
			int num = SwimmingCompetition.maleSwimmers.size();
			for (int n = 0; n < num; ++n) {
				MaleSwimmer swimmer = SwimmingCompetition.maleSwimmers.get(n);
				swimmer.setLane(SwimmingCompetition.pool.getLaneList().get(n));
				SwimmingCompetition.pool.getLaneList().get(n).setSwimmer(swimmer);
			}
		}
		
		else {
			int num = SwimmingCompetition.femaleSwimmers.size();
			for (int n = 0; n < num; ++n) {
				FemaleSwimmer swimmer = SwimmingCompetition.femaleSwimmers.get(n);
				swimmer.setLane(SwimmingCompetition.pool.getLaneList().get(n));
				SwimmingCompetition.pool.getLaneList().get(n).setSwimmer(swimmer);
			}
			
		}
	}
	
	// Returns a list of names of the created swimmers
	public static String [] getNames(String gender) {
		if (gender == "Male") {
			SwimmingCompetition.competitionType = "Male";
			int num = SwimmingCompetition.maleSwimmers.size();
			String [] nameArray = new String [num];
			for (int n = 0; n < num; ++n) {
				MaleSwimmer swimmer = SwimmingCompetition.maleSwimmers.get(n);
				String name = swimmer.getName();
				nameArray[n] = name;
			}
			
			return nameArray;
		}
		
		else {
			SwimmingCompetition.competitionType = "Female";
			int num = SwimmingCompetition.femaleSwimmers.size();
			String [] nameArray = new String [num];
			for (int n = 0; n < num; ++n) {
				FemaleSwimmer swimmer = SwimmingCompetition.femaleSwimmers.get(n);
				String name = swimmer.getName();
				nameArray[n] = name;
			}
			
			return nameArray;
		}
		
	}
	
	
}