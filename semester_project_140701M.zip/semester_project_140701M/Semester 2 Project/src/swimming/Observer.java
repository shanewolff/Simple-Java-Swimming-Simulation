package swimming;

import java.util.ArrayList;

// Common method for observers
public interface Observer {
	public void update(ArrayList<ArrayList<Object>> finalResults2);
}
