
package swimming;

import java.util.ArrayList;

//Inherits fields and methods from Person class
public class Spectator extends Person implements Observer {
    private ArrayList<ArrayList<Object>> result;
	//Constructor
    public Spectator(String name) {
        super(name); //Calls the constructor of the super class
        SwimmingCompetition.spectators.add(this); //Adds newly created object to the array list
    }

    // Receive the updates from the observables
	@Override
	public void update(ArrayList<ArrayList<Object>> result) {
		this.result = result;
	}
}
