package swimming;

//Common methods for implementation by both male and female swimmers but in different ways
public interface ISwimmer {
	public String getSuitColour();
	public double butterflyStroke();
	public double backStroke();
	public double breastStroke();
	public double freeStyle();
}
