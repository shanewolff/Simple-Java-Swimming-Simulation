package swimming;

import java.util.ArrayList;

public class Pavillion {
	private ArrayList<Spectator> spectators;
	
	public Pavillion() {
		spectators = new ArrayList<Spectator>();
	}
	
	// Add spectators into the pavillion
	public void addSpectators(ArrayList<Spectator> spectators) {
		this.spectators = spectators;
	}
}
