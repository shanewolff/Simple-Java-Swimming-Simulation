package swimming;

//Super class of people in the simulation
public abstract class Person {
	
	private String name; //Name field
	
	public Person(String name) { //Constructor
		this.name = name;
		SwimmingCompetition.persons.add(this); //Adds newly created object to the array list
	}
	
	//Returns the name of a person
	public String getName() {
		return name;
	}
}
