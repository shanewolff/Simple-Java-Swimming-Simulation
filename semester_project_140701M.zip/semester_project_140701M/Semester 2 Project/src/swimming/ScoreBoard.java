package swimming;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class ScoreBoard implements Observable {
	private long startTime;								// Stores the start time of the competition
	private ArrayList<Observer> spectators;				// Stores a list of spectators to notify 
	private ArrayList<ArrayList<Object>> finalResults;	// Stores the final result of the competition
	
	// Constructor
	public ScoreBoard() {
		spectators = new ArrayList<Observer>();
		finalResults = new ArrayList<ArrayList<Object>>();
	}
	
	// Saves the final result of the competition to a storage
	public void saveResult() {
		File f = new File("result.out");
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(f);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ObjectOutputStream oos = null;
		try {
			oos = new ObjectOutputStream(fos);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			oos.writeObject(finalResults);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	// Returns the final result
	public ArrayList<ArrayList<Object>> getFinalResults() {
		return finalResults;
	}
	
	// Keeping track of results of the competition
	public synchronized void sendResult(Swimmer swimmer, long time) {
		ArrayList<Object> result = new ArrayList<Object>(); 
		result.add((String) swimmer.getName());
		float elapsedTime = (float) ((float) (time - startTime) / 1000.000);
		result.add(elapsedTime);
		finalResults.add(result);
	}
	
	// Notify the final result 
	public void setScoreBoard() {
		notify(finalResults);
	}
	
	// Sets the start time of the competition
	public void setStartTime(long time) {
		startTime = time;
	}
	
	// Registers the observers
	@Override
	public void register(Observer spectator) {
		spectators.add(spectator);
	}
	
	// Unregisters the observers
	@Override
	public void unregister(Observer spectator) {
		spectators.remove(spectators.indexOf(spectator));
	}
	
	// Notify observers the final result
	@Override
	public void notify(ArrayList<ArrayList<Object>> finalResults2) {
		for (Observer i : spectators) {
			i.update(finalResults2);
		}
		
	}
}
