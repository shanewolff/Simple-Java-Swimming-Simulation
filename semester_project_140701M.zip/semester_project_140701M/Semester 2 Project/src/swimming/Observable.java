package swimming;

import java.util.ArrayList;

// Common methods for observables
public interface Observable {
	public void register(Observer spectator);
	public void unregister(Observer spectator);
	public void notify(ArrayList<ArrayList<Object>> result);
}
