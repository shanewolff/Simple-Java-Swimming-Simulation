package swimming;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.CardLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JButton;

// First Window
public class GUI_1 extends JFrame {
	
	// Declaration of window components
	private JTextField textField_swimmerName;
	private JTextField textField_swimmerAge;
	private JPanel panel1;
	private JLabel label_intro;
	private JLabel label_createSwimmers;
	private JLabel lblChooseTheGender;
	private JComboBox<String> comboBox_gender;
	private JLabel label_swimmerName;
	private JLabel label_swimmerAge;
	private JButton button_createSwimmer;
	private JButton button_createCompetititon;
	private JTextField textField_judgeName;
	private JLabel label_createJudge;
	private JLabel label_judgeName;
	private JButton button_createJudge;
	private JLabel label_creatStaff;
	private JLabel label_staffName;
	private JTextField textField_staffName;
	private JButton button_createStaff;
	private JLabel lblNewLabel;
	private JLabel label_spectatorName;
	private JTextField textField_spectatorName;
	private JButton button_createSpectator;
	private JFrame frame2;
	private JLabel label_createOthers;

	/**
	 * Launch the application.
	 */
	
	// Main method, application starts here
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					new SwimmingCompetition();
					GUI_1 frame1 = new GUI_1();
					frame1.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	// COnstructor
	public GUI_1() {
		setResizable(false);
		setFont(null);
		setTitle("Swimming Competition - Create New Competiton");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 460, 489);
		getContentPane().setLayout(new CardLayout(0, 0));
		
		panel1 = new JPanel();
		getContentPane().add(panel1, "1");
		panel1.setLayout(null);
		
		String text_intro = "<html>\n"
				+ "<p align = \"justify\">\n"
				+ "This is a simple simulation of a swimming competition. "
				+ "Follow the instructions to commence the simulation.\n"
				+ "</p>\n"
				+ "</html>";
		
		label_intro = new JLabel(text_intro);
		label_intro.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_intro.setBounds(10, 11, 433, 28);
		panel1.add(label_intro);
		
		String text_create = "<html>\n"
				+ "<p align = \"justify\">\n"
				+ "Create new Swimmers. Fill the required fields. "
				+ "Names should be unique. Required to create at least "
				+ "two swimmers from both gender and maximum of 5 from each."
				+ "</p>\n"
				+ "</html>";
		
		label_createSwimmers = new JLabel(text_create);
		label_createSwimmers.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		label_createSwimmers.setBounds(10, 50, 433, 40);
		panel1.add(label_createSwimmers);
		
		lblChooseTheGender = new JLabel("Choose the gender of the swimmer");
		lblChooseTheGender.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblChooseTheGender.setBounds(10, 101, 174, 14);
		panel1.add(lblChooseTheGender);
		
		comboBox_gender = new JComboBox<String>();
		comboBox_gender.setFont(new Font("Tahoma", Font.PLAIN, 11));
		comboBox_gender.setModel(new DefaultComboBoxModel<String>(new String[] {"Male", "Female"}));
		comboBox_gender.setBounds(194, 98, 66, 20);
		panel1.add(comboBox_gender);
		
		label_swimmerName = new JLabel("Name of the Swimmer");
		label_swimmerName.setFont(new Font("Tahoma", Font.PLAIN, 11));
		label_swimmerName.setBounds(10, 129, 104, 14);
		panel1.add(label_swimmerName);
		
		label_swimmerAge = new JLabel("Age of the Swimmer");
		label_swimmerAge.setFont(new Font("Tahoma", Font.PLAIN, 11));
		label_swimmerAge.setBounds(10, 160, 96, 14);
		panel1.add(label_swimmerAge);
		
		textField_swimmerName = new JTextField();
		textField_swimmerName.setFont(new Font("Tahoma", Font.PLAIN, 11));
		textField_swimmerName.setBounds(134, 126, 143, 20);
		panel1.add(textField_swimmerName);
		textField_swimmerName.setColumns(10);
		
		textField_swimmerAge = new JTextField();
		textField_swimmerAge.setFont(new Font("Tahoma", Font.PLAIN, 11));
		textField_swimmerAge.setBounds(134, 157, 45, 20);
		panel1.add(textField_swimmerAge);
		textField_swimmerAge.setColumns(10);
		
		button_createSwimmer = new JButton("Create the Swimmer");
		button_createSwimmer.setFont(new Font("Tahoma", Font.BOLD, 11));
		button_createSwimmer.setBounds(287, 156, 156, 23);
		panel1.add(button_createSwimmer);
		
		button_createCompetititon = new JButton("Create the Competition");
		button_createCompetititon.setFont(new Font("Tahoma", Font.BOLD, 11));
		button_createCompetititon.setBounds(269, 426, 174, 23);
		panel1.add(button_createCompetititon);
		
		label_createJudge = new JLabel("Create a new Judge");
		label_createJudge.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		label_createJudge.setBounds(10, 228, 143, 14);
		panel1.add(label_createJudge);
		
		label_judgeName = new JLabel("Name of the Judge");
		label_judgeName.setFont(new Font("Tahoma", Font.PLAIN, 11));
		label_judgeName.setBounds(10, 253, 104, 14);
		panel1.add(label_judgeName);
		
		textField_judgeName = new JTextField();
		textField_judgeName.setFont(new Font("Tahoma", Font.PLAIN, 11));
		textField_judgeName.setBounds(134, 250, 143, 20);
		panel1.add(textField_judgeName);
		textField_judgeName.setColumns(10);
		
		button_createJudge = new JButton("Create the Judge");
		button_createJudge.setFont(new Font("Tahoma", Font.BOLD, 11));
		button_createJudge.setBounds(287, 249, 156, 23);
		panel1.add(button_createJudge);
		
		label_creatStaff = new JLabel("Create Supporting Staff");
		label_creatStaff.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		label_creatStaff.setBounds(10, 298, 156, 14);
		panel1.add(label_creatStaff);
		
		label_staffName = new JLabel("Name of the Staff");
		label_staffName.setFont(new Font("Tahoma", Font.PLAIN, 11));
		label_staffName.setBounds(10, 322, 104, 14);
		panel1.add(label_staffName);
		
		textField_staffName = new JTextField();
		textField_staffName.setFont(new Font("Tahoma", Font.PLAIN, 11));
		textField_staffName.setBounds(134, 319, 143, 20);
		panel1.add(textField_staffName);
		textField_staffName.setColumns(10);
		
		button_createStaff = new JButton("Create the Staff");
		button_createStaff.setFont(new Font("Tahoma", Font.BOLD, 11));
		button_createStaff.setBounds(287, 318, 156, 23);
		panel1.add(button_createStaff);
		
		lblNewLabel = new JLabel("Create Spectators");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		lblNewLabel.setBounds(10, 363, 118, 14);
		panel1.add(lblNewLabel);
		
		label_spectatorName = new JLabel("Name of the Spectator");
		label_spectatorName.setFont(new Font("Tahoma", Font.PLAIN, 11));
		label_spectatorName.setBounds(10, 388, 118, 14);
		panel1.add(label_spectatorName);
		
		textField_spectatorName = new JTextField();
		textField_spectatorName.setFont(new Font("Tahoma", Font.PLAIN, 11));
		textField_spectatorName.setColumns(10);
		textField_spectatorName.setBounds(134, 385, 143, 20);
		panel1.add(textField_spectatorName);
		
		button_createSpectator = new JButton("Create the Spectator");
		button_createSpectator.setFont(new Font("Tahoma", Font.BOLD, 11));
		button_createSpectator.setBounds(287, 384, 156, 23);
		panel1.add(button_createSpectator);
		
		label_createOthers = new JLabel("Create at least one person from the following.");
		label_createOthers.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		label_createOthers.setBounds(10, 203, 267, 14);
		panel1.add(label_createOthers);
		
		// Creates swimmer objects
		button_createSwimmer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String name = textField_swimmerName.getText();
				String age = textField_swimmerAge.getText();
				String gender = (String) comboBox_gender.getSelectedItem();
				Control.addSwimmer(gender, name, age);
				textField_swimmerName.setText("");
				textField_swimmerAge.setText("");
			}
		});
		
		// Creates Judge objects
		button_createJudge.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String name = textField_judgeName.getText();
				Control.addJudge(name);
				textField_judgeName.setText("");
			}
		});
		
		//Creates staff objects
		button_createStaff.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = textField_staffName.getText();
				Control.addStaff(name);
				textField_staffName.setText("");
			}
		});
		
		// Create spectator objects
		button_createSpectator.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = textField_spectatorName.getText();
				Control.addSpectator(name);
				textField_spectatorName.setText("");
			}
		});
		
		// Verify the created number of objects and transfer from first window to second 
		button_createCompetititon.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (Verify.isValidToStart()) {
					transition();
				}
				
				else {
					JOptionPane.showMessageDialog(null, "The number of human resources created "
							+ "is not sufficient to start the competition.","Insufficient Human Resources", 0);
				}
			}
		});
	}
	
	// Transition from first window to second
	private void transition() {
		this.setVisible(false);
		frame2 = new GUI_2();
		frame2.setVisible(true);
	}
}
